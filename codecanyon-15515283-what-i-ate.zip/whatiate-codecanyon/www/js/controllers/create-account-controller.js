var app = angular.module('whatiate');

app.controller('CreateAccountCtrl', function($ionicLoading, $ionicPopup, $log, $scope, $state, $timeout, AuthService) {
  $scope.resetFormData = function() {
    $scope.createAccoutnFormData = {
      'email': '',
      'password': ''
    };
  };
  $scope.resetFormData();

  $scope.createAccount = function(form) {
    if (form.$valid) {
      $ionicLoading.show();
      AuthService.createAccount($scope.createAccoutnFormData)
        .then(loginAfterAccountCreated)
        .then(redirectAfterLoginWithEmailAndPassword)
        .catch(errorHandler);
    }
  };

  var loginAfterAccountCreated = function(userData) {
    $log.info(userData);
    return AuthService.loginWithEmailAndPassword($scope.createAccoutnFormData);
  };

  var redirectAfterLoginWithEmailAndPassword = function(authData) {
    $log.info(authData);
    $timeout(function() {
      $ionicLoading.hide();
      $scope.resetFormData();
      $state.go('authenticated');
    }, 2000);
  };

  var errorHandler = function(error) {
    $log.error(error);
    $ionicLoading.hide();
    $ionicPopup.alert({
      title: 'Error creating account',
      subTitle: error
    });
  };
});
