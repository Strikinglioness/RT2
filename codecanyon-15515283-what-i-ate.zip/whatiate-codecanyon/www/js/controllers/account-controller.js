var app = angular.module('whatiate');

app.controller('AccountCtrl', function($scope, AuthService) {
  $scope.user = AuthService.user;
  $scope.logout = function() {
    AuthService.logout();
  };
});
