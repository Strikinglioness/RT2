// Ionic WhatIAte App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'

var app = angular.module('whatiate', ['ionic', 'firebase', 'ngMessages', 'ngCordova', 'angularMoment']);

app.constant('firebaseUrl', 'https://YOURFIREBASEAPP.firebaseio.com');

// nutritionix.com
app.constant('nutritionixApi', {
  credentials: {
    appId: 'APPID',
    appKey: 'APPKEY'
  },
  barcode: {
    url: 'https://api.nutritionix.com/v1_1/item?upc=[BARCODE]&appId=[APPID]&appKey=[APPKEY]'
  },
  text: {
    url: 'https://api.nutritionix.com/v1_1/search/[TEXT]?results=0:50&fields=[FIELDS]&appId=[APPID]&appKey=[APPKEY]',
    fields: ['brand_name', 'item_name', 'brand_id', 'item_id', 'upc', 'item_type', 'item_description', 'nf_ingredient_statement', 'nf_water_grams', 'nf_calories', 'nf_calories_from_fat', 'nf_total_fat', 'nf_saturated_fat', 'nf_monounsaturated_fat', 'nf_polyunsaturated_fat', 'nf_trans_fatty_acid', 'nf_cholesterol', 'nf_sodium', 'nf_total_carbohydrate', 'nf_dietary_fiber', 'nf_sugars', 'nf_protein', 'nf_vitamin_a_iu', 'nf_vitamin_a_dv', 'nf_vitamin_c_mg', 'nf_vitamin_c_dv', 'nf_calcium_mg', 'nf_calcium_dv', 'nf_iron_mg', 'nf_iron_dv', 'nf_potassium', 'nf_refuse_pct', 'nf_servings_per_container', 'nf_serving_size_qty', 'nf_serving_size_unit', 'nf_serving_weight_grams', 'allergen_contains_milk', 'allergen_contains_eggs', 'allergen_contains_fish', 'allergen_contains_shellfish', 'allergen_contains_tree_nuts', 'allergen_contains_peanuts', 'allergen_contains_wheat', 'allergen_contains_soybeans', 'allergen_contains_gluten', 'images_front_full_url', 'updated_at', 'section_ids']
  }
});

// foursquare.com
app.constant('foursquareApi', {
  credentials: {
    clientId: 'CLIENTID',
    clientSecret: 'CLIENTSECRET'
  },
  url: 'https://api.foursquare.com/v2/venues/search?ll=[LAT],[LONG]&intent=browse&radius=30&client_id=[CLIENT_ID]&client_secret=[CLIENT_SECRET]&v=20151201'
});

// maps.googleapis.com geocode
app.constant('googleGeocodeApi', {
  credentials: {
    key: 'KEY'
  },
  url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng=[LAT],[LONG]&key=[KEY]'
});

// maps.googleapis.com staticmap
app.constant('googleMapsApi', {
  url: 'https://maps.googleapis.com/maps/api/staticmap?center=[LAT],[LONG]zoom=13&size=300x300&maptype=roadmap&markers=color:blue%7Clabel:X%7C[LAT],[LONG]'
});


app.constant('chunkSize', 3);

// AWS
app.constant('AwsConfig', {
  AKID: 'APPKEY',
  SAK: 'SECRETKEY',
  BUCKET: 'BUCKET',
  REGION: 'REGION'
});

app.run(function($ionicLoading, $ionicPlatform, $ionicPopup, $log, $rootScope, $state, $timeout, AuthService) {
  $ionicPlatform.ready(function() {
    if (window.Connection) {
      var onOffline = function() {
        $ionicPopup.alert({
            title: 'No Internet Connection',
            content: 'Sorry, no Internet connectivity detected. Please reconnect and try again.'
          })
          .then(function(result) {
            ionic.Platform.exitApp();
          });
        $rootScope.offline = true;
      };
      var onOnline = function() {
        $rootScope.offline = false;
      };
      if (navigator.connection.type == Connection.NONE) {
        onOffline();
      }
      $rootScope.$on('$cordovaNetwork:offline', onOffline);
      $rootScope.$on('$cordovaNetwork:online', onOnline);
    }
    if (window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
    if (navigator.splashscreen) {
      $timeout(function() {
        navigator.splashscreen.hide();
      }, 1000);
    }
  });
  $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
    var user = AuthService.user;
    if (toState.authenticate && !user) {
      event.preventDefault();
      $state.go('login');
      return;
    }
  });
});

// some exception handling
app.config(function($provide) {
  $provide.decorator('$exceptionHandler', ['$delegate', '$window', '$log', function($delegate, $window, $log) {
    return function(exception, cause) {
      console.error('$exceptionHandler ', exception);
      console.error('$exceptionHandler stack', exception.stack);
    };
  }]);
});

// app states configuration
app.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

  $ionicConfigProvider.navBar.alignTitle('center');
  $ionicConfigProvider.tabs.position('bottom');

  $stateProvider
    .state('login', {
      url: "/login",
      cache: false,
      controller: 'LoginCtrl',
      templateUrl: "templates/login.html"
    })
    .state('create-account', {
      url: "/create-account",
      controller: 'CreateAccountCtrl',
      templateUrl: "templates/create-account.html"
    })
    .state('tab', {
      url: "/tab",
      abstract: true,
      templateUrl: "templates/tabs.html"
    })
    .state('tab.meals', {
      url: '/meals',
      views: {
        'tab-meals': {
          templateUrl: 'templates/tabs/tab-meals.html',
          controller: 'MealListCtrl'
        }
      },
      authenticate: true
    })
    .state('tab.comments', {
      url: '/comments/:id',
      views: {
        'tab-meals': {
          templateUrl: 'templates/tabs/meal-comments.html',
          controller: 'MealCommentsCtrl'
        }
      },
      authenticate: true
    })
    .state('tab.user-profile', {
      url: '/user-profile/:uid',
      views: {
        'tab-meals': {
          templateUrl: 'templates/tabs/meal-user-profile.html',
          controller: 'UserProfileCtrl'
        }
      },
      authenticate: true
    })
    .state('tab.track', {
      url: '/track',
      views: {
        'tab-track': {
          templateUrl: 'templates/tabs/tab-track.html',
          controller: 'MealTrackCtrl'
        }
      },
      authenticate: true
    })
    .state('tab.account', {
      url: '/account/',
      views: {
        'tab-account': {
          templateUrl: 'templates/tabs/tab-account.html',
          controller: 'AccountCtrl'
        }
      },
      authenticate: true
    });

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/login');
});
