var app = angular.module('whatiate');

app.controller('LoginCtrl', function($ionicLoading, $ionicPopup, $log, $rootScope, $scope,
  $state, $timeout, AuthService) {
  $scope.resetFormData = function() {
    $scope.loginFormData = {
      email: '',
      password: ''
    };
  };
  $scope.resetFormData();

  $scope.login = function(provider, form) {
    if ('password' === provider) {
      if (form.$valid) {
        AuthService.loginWithEmailAndPassword($scope.loginFormData)
          .then(redirectAfterLoginWithEmailAndPassword)
          .catch(errorHandler);
      }
    } else {
      AuthService.thirdPartyLogin(provider);
    }
  };

  var redirectAfterLoginWithEmailAndPassword = function(authData) {
    $log.info(authData);
    $timeout(function() {
      $ionicLoading.hide();
      $scope.resetFormData();
      $state.go('tab.meals');
    }, 2000);
  };

  var errorHandler = function(error) {
    $log.error(error);
    $ionicLoading.hide();
    $ionicPopup.alert({
      title: 'Login error',
      subTitle: error
    });
  };

  // Listen for AuthService auth event
  AuthService.usersAuth.$onAuth(function(authData) {
    if (authData && !$rootScope.offline) {
      $log.info("Logged in as:", authData);
      AuthService.setUser(authData);
      $scope.user = AuthService.user;
      $ionicLoading.show({
        template: authData[authData.provider].displayName ? 'Logged in as ' + authData[authData.provider].displayName + '!' : 'Login success',
        duration: 2000
      });
      $timeout(function() {
        $state.go('tab.meals');
      }, 2000);
    } else {
      $scope.user = null;
      AuthService.logout();
    }
  });
});
