var app = angular.module('whatiate');

app.controller('UserProfileCtrl', function($scope, $stateParams, AuthService) {
  $scope.user = AuthService.getUserById($stateParams.uid);
});
